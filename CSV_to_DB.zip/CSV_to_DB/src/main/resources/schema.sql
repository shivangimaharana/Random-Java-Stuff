CREATE TABLE STUDENTS( 
    roll VARCHAR(10) NOT NULL, 
    name VARCHAR(20), 
    age int(10),
    primary key(roll) 
);