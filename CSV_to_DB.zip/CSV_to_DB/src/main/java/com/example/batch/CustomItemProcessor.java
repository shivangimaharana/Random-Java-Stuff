package com.example.batch;

import org.springframework.batch.item.ItemProcessor;

public class CustomItemProcessor implements ItemProcessor<Students,Students>{

	@Override
	public Students process(Students item) throws Exception {
		System.out.println("Processing..." + item);
		return item;
	}

}
