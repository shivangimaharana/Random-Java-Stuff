package com.example.batch;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class CsvToDbApplication {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(CsvToDbApplication.class, args);
		
		System.err.println("Starting the Batch Job");
	      
	    ApplicationContext context = new ClassPathXmlApplicationContext("batch-config.xml"); 
	      
	    JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher"); 
	      
	    Job job = (Job) context.getBean("job_id1");  
	    JobExecution execution = jobLauncher.run(job, new JobParameters());        
	    System.err.println("Exit Status : " + execution.getStatus());      
	    ((ClassPathXmlApplicationContext) context).close();
	}

}
