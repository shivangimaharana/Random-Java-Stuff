package com.example.batch;

import org.springframework.batch.item.file.transform.FieldSet;

public class StudentSetMapper{
	
	public Students mapFieldSet(FieldSet fieldSet) {
		
		Students student = new Students();
		student.setRoll(fieldSet.readString(0));
		student.setName(fieldSet.readString(1));
		student.setAge(fieldSet.readInt(2));
		
		return student;
	}
}
